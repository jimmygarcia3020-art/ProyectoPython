# DEF DE LA COLA PRIORITARIA

import heapq
import itertools

class Carro:
    def __init__(self, placa, marca, modelo, llegada):
        self.placa = placa
        self.marca = marca
        self.modelo = modelo
        self.llegada = llegada

    def __str__(self):
        return f"{self.placa} - {self.marca} {self.modelo}, llegada {self.llegada}"


class ColaPrioritaria:
    def __init__(self):
        self.heap = []
        self.counter = itertools.count()

    def encolar(self, carro):
        orden_llegada = next(self.counter)
        heapq.heappush(self.heap, (orden_llegada, carro))

    def desencolar(self):
        if not self.heap:
            return None
        return heapq.heappop(self.heap)[1]

    def ver_primero(self):
        if not self.heap:
            return None
        return self.heap[0][1]

    def esta_vacia(self):
        return len(self.heap) == 0









# QUE SE VALLAN APILANDO EN UN ARREGLO

class PilaCarros:
    def __init__(self):
        self.arreglo = []

    def apilar(self, carro):
        self.arreglo.append(carro)

    def desapilar(self):
        if not self.arreglo:
            return None
        return self.arreglo.pop()

    def ver_tope(self):
        if not self.arreglo:
            return None
        return self.arreglo[-1]

    def mostrar(self):
        return list(reversed(self.arreglo))







# ARBOL BINARIO

class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.izquierda = None
        self.derecha = None

def re_inorden(raiz):
    if raiz is None:
        return
    re_inorden(raiz.izquierda)
    print(raiz.valor, end=" | ")
    re_inorden(raiz.derecha)

def re_preorden(raiz):
    if raiz is None:
        return
    print(raiz.valor, end=" | ")
    re_preorden(raiz.izquierda)
    re_preorden(raiz.derecha)

def re_posorden(raiz):
    if raiz is None:
        return
    re_posorden(raiz.izquierda)
    re_posorden(raiz.derecha)
    print(raiz.valor, end=" | ")
    



















    #PRUEBAS 

cola = ColaPrioritaria()

carro1 = Carro("ABC-123", "Toyota", "Corolla", 1)
carro2 = Carro("DFC-999", "BMW", "M3", 2)
carro3 = Carro("XYZ-789", "Nissan", "Skyline", 3)
carro4 = Carro("CHK-111", "Audi", "R8", 4)

cola.encolar(carro1)
cola.encolar(carro2)
cola.encolar(carro3)
cola.encolar(carro4)

print("\n=== Orden en la cola (el primero en atender) ===")
print(cola.ver_primero())

print("\n=== Atendiendo carros ===")
while not cola.esta_vacia():
    carro_atendido = cola.desencolar()
    print("Atendido:", carro_atendido)

print("# PRUEBAS DE PILA (Stack de autos)\n")




pila = PilaCarros()

print("Apilando carros...")
pila.apilar(carro1)
pila.apilar(carro2)
pila.apilar(carro3)
pila.apilar(carro4)

print("Carros apilados (vista de la pila, tope primero):")
for c in pila.mostrar():
    print(" -", c)

print("\nTope actual de la pila:")
print(" >", pila.ver_tope())

print("\nDesapilando...")
print("Salió:", pila.desapilar())
print("Nuevo tope:", pila.ver_tope())

print("\nDesapilando todos...")
while pila.ver_tope() is not None:
    print("Salió:", pila.desapilar())

print("\nIntentando desapilar cuando está vacía:")
print("Resultado:", pila.desapilar())

print("\nEstado final de la pila:", pila.mostrar())
print("\n" + "°" * 40)



print("°°°°°°°°°°°°°°°°°°°°°°°")


raiz = Nodo(carro1)
raiz.izquierda = Nodo(carro2)
raiz.derecha = Nodo(carro3)
raiz.izquierda.izquierda = Nodo(carro4)
re_inorden(raiz)
